# Eyad Mohamed — Personal Website

A simple black personal profile website.

## Files
- `index.html` — the complete website.

## Publish with GitHub Pages
1. Create a GitHub repository.
2. Upload `index.html`.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select the `main` branch and `/ (root)`.
6. Save and wait for GitHub Pages to publish the site.
